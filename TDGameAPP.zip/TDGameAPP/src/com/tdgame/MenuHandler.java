package com.tdgame;


import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.Timer;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

/**
 * 
 * @author Team 2
 *
 * MenuHandler class handles the Menu events and takes appropriate action based upon the user choice
 */

public class MenuHandler implements ActionListener{
	
	Screen screen;
	Frame frame;
	JButton myButton; 
	
	MenuHandler() {}
	
	MenuHandler(Frame frame) {

		this.frame = frame;		
		screen = new Screen(frame);
		this.frame.getContentPane().add(screen);
		this.frame.getContentPane().validate();
	}
	

	// this method catches the menu events and handles them accordingly
	@Override
	public void actionPerformed(ActionEvent e) {

		ActionHandler actionHandler = new ActionHandler();
		MouseHandler mouseHandler = new MouseHandler(screen);
		
		myButton = (JButton) e.getSource();
	    
		String selectedOption = myButton.getText();
		
		if(selectedOption.equalsIgnoreCase("Create Map")) {
			Screen.startGame = false;
			screen.createMap();			
		} else if(selectedOption.equalsIgnoreCase("Load Map")) {
			Screen.startGame = false;
			screen.loadMap();
		} else if(selectedOption.equalsIgnoreCase("Save Map")) {
			Screen.startGame = false;
			mouseHandler.saveMapByMenu();
		} else if(selectedOption.equalsIgnoreCase("Instructions")) {
			Screen.startGame = false;
			actionHandler.menuInstructions();
		} else if(selectedOption.equalsIgnoreCase("Edit Map")) {
			Screen.startGame = false;
			actionHandler.editMap();
			mouseHandler.mapReadyForEditing();
		}
		
		myButton.setSelected(false);
		
	}

}
