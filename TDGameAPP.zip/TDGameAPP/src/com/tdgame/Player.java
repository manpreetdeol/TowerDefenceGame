package com.tdgame;

public class Player{

	public int health;
	public int money;
	
	
	public Player(User user) {
		this.money = user.startingCash;
		this.health = user.startingHealth;
	}

}
