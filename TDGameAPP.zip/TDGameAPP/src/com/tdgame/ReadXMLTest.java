package com.tdgame;

import static org.junit.Assert.*;

import javax.swing.JTextField;

import org.junit.Test;

public class ReadXMLTest {

	@Test
	public void testReadXML() throws Exception {
		int valueX = 0;
		int valueY = 0;
		Screen screen = new Screen(new Frame());
		String fileName = "";
		
		ReadXML result = new ReadXML(valueX, valueY, screen, fileName);
		assertNotNull(result);
	}
	
	@Test
	public void testGetLengthOfExistingMap() throws Exception {
			ReadXML fixture = new ReadXML(18, 18, new Screen(new Frame()), "");
			String newFileName = "osama.xml";

			String result = fixture.getLengthOfExistingMap(newFileName);
			System.out.println(result);
			// add additional test code here
			assertNotEquals("0_0", result);
		}
}
