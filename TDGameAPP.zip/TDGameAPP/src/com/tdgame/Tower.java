package com.tdgame;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 * 
 * @author Team 2
 * 
 * This class sets all the tower attributes like id cost and range
 *
 */

public class Tower extends JButton {
	
	public String imageFile = "";
	public Image image;
	public static Tower[] towerList = new Tower[200];
	public static Tower lighteningTower = new TowerTypes(0, 10, 2,"").getImageFile("tower2"); //10 is tower cost, default range is 2
	public int id;
	public int cost;
	public int range;
	public int health;
	public String type;
	
	
	public Tower()
	{
		super();
	}
	public Tower(ImageIcon icon)
	{
		super(icon);
	}
	public Tower(int id, int cost, int range,String type){
		if(towerList[id] != null){
			System.out.println("[TowerInitialization] Two towers with same id\t" + id);
		}else{
			this.id = id;
			this.cost = cost;
			this.range = range;
			towerList[id] = this;
			this.type=type;
		}
	}
	
	public Tower getImageFile(String str){
		this.imageFile = str;
		this.image = new ImageIcon("res/towers/" + this.imageFile + ".png").getImage();
		return this;
	}
}
