package com.tdgame;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TowerTest {

	int id;
	int cost;
	int range;
	boolean towerIdRepeatCheck;
	
	@Before
	public void setContext()
	{
		id = 0;
		cost = 10;
		range = 2;
		towerIdRepeatCheck = false;
	}
	
	@Test
	public void test() {
		Tower lighteningTower = new TowerTypes(id, cost, range,"");
		if(lighteningTower.towerList[id] != null)
		{
			towerIdRepeatCheck = true;
		}
		assertTrue(towerIdRepeatCheck);
	}

}
