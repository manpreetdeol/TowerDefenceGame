package com.tdgame;

public class TowerTypes extends Tower{

	public TowerTypes(int id, int cost, int range,String type){	
		super(id, cost, range,type);
	}

}
