package com.tdgame;

public class User {

	private Screen screen;
	
	Player player;
	
	public int startingCash = 30;
	public int startingHealth = 100;
	
	public User(Screen screen) {
		this.screen = screen;
		this.screen.scene = 0;//sets scene to the welcome screen
	}
	
	public void createPlayer(){ 
		this.player = new Player(this);
	}

}
